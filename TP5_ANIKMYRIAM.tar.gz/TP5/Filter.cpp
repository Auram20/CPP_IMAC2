// ================================
// POO C++ - IMAC 2
// TP 5 
// ANIK Myriam
// ================================


#include "Filter.hpp"

// Constructeur
Filter::Filter() {}

// Destructeur
Filter::~Filter() {}
